import db_ops
import json

print("loading configuraitons")


config = {}
with open('job_config.json', 'r') as f:
    config = json.load(f)

user = config['user']
passwd = config['passwd']
server = config['server']
port = config['port']
db = config['db']
stg_schema = config['stg_schema']
sum_schema = config['sum_schema']
created_by_user = config['created_by_user']


print("start processing")

connection = db_ops.create_connection(user, passwd, server, port, db)

global_summary_query = f"""INSERT INTO {sum_schema}."global_summary"(REPORT_DATE, NO_OF_DISTINCT_USERS, NO_OF_REQUESTS, NO_OF_SUCCESSFULL_REQ, NO_OF_SERVER_ERRORS, CREATED_BY)
SELECT 
FILE_DATE AS report_date,
count(DISTINCT USER_ID) AS no_of_distinct_users,
count(*) AS no_of_requests,
count(CASE WHEN RESPONSE_STATUS>=200 AND RESPONSE_STATUS<=299 THEN 1 ELSE NULL END) AS  no_of_successfull_req,
count(CASE WHEN RESPONSE_STATUS>=500 AND RESPONSE_STATUS<=599 THEN 1 ELSE NULL END) AS  no_of_server_errors,
'{created_by_user}' created_by
FROM {stg_schema}.WEB_SERVER_LOGS
GROUP BY FILE_DATE"""

user_summary_query = f"""INSERT INTO {sum_schema}."user_level_summary"
(REPORT_DATE, USER_ID, NO_OF_REQUESTS, NO_OF_SUCCESSFULL_REQ, NO_OF_CLIENT_ERRORS, CREATED_BY)
SELECT 
FILE_DATE AS REPORT_DATE,
USER_ID,
count(*) AS NO_OF_REQUESTS,
count(CASE WHEN RESPONSE_STATUS>=200 AND RESPONSE_STATUS<=299 THEN 1 ELSE NULL END) AS  NO_OF_SUCCESSFULL_REQ,
count(CASE WHEN RESPONSE_STATUS>=400 AND RESPONSE_STATUS<=499 THEN 1 ELSE NULL END) AS  NO_OF_CLIENT_ERRORS,
'{created_by_user}' created_by
FROM {stg_schema}.WEB_SERVER_LOGS
GROUP BY FILE_DATE, USER_ID"""

print("inserting data")

with connection.cursor() as cursor:
    cursor.execute(global_summary_query)
    cursor.execute(user_summary_query)

print("Commit and connection close")
connection.commit()
connection.close()