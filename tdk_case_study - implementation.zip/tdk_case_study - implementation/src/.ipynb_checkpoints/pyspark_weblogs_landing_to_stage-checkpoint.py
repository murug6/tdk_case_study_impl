import re
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from datetime import datetime as DT
import json

def replace_space_in_dt(s):
    return re.sub("([\w:/]+\s[+-]\d{4})", lambda s: s.group(1).replace(" ", "Z"), s)


print("loading configuraitons")

config = {}
with open('job_config.json', 'r') as f:
    config = json.load(f)

user = config['user']
passwd = config['passwd']
server = config['server']
port = config['port']
db = config['db']
stg_schema = config['stg_schema']
created_by_user = config['created_by_user']
data_path = config['data_path']
file_name = config['file_name']

print("start processing")

spark = SparkSession.builder.appName("web logs").getOrCreate()

replace_space_in_dt = udf(replace_space_in_dt)

df = spark.read.text(f'{data_path}{file_name}')

df3 = df.withColumn("value", regexp_replace(replace_space_in_dt(df.value), '"', '')) # to remove the space in request timestamp

df_final = df3.withColumn('host_ip', split(df3['value'], ' ').getItem(0)) \
.withColumn('client_id', when(split(df3['value'], ' ').getItem(1) =="-", None).otherwise(split(df3['value'], ' ').getItem(1))) \
.withColumn('user_id', split(df3['value'], ' ').getItem(2).cast('int')) \
.withColumn('request_timestamp', to_timestamp(split(df3['value'], ' ').getItem(3),"'['dd/MMM/yyyy:HH:mm:ss'Z'ZZ']'")) \
.withColumn('request_method', split(df3['value'], ' ').getItem(4)) \
.withColumn('requested_obj', split(df3['value'], ' ').getItem(5)) \
.withColumn('request_protocol', split(df3['value'], ' ').getItem(6)) \
.withColumn('response_status', split(df3['value'], ' ').getItem(7).cast('int')) \
.withColumn('response_object_size', split(df3['value'], ' ').getItem(8).cast('int')) \
.withColumn('file_date', to_date(lit(file_name.split('.')[0]), 'yyyy-MM-dd')) \
.withColumn('created_by', lit(created_by_user)).drop(df3["value"])


# when(col("client_id")=="-" ,None).otherwise(col("client_id")) \
# f.withColumn("client_id",when(col("client_id1")=="-" ,None).otherwise(col("client_id1"))).show()

# df_final = df4.drop(df4["value"])

print("inserting data")

df_final.write.format('jdbc').options(
      url=f'jdbc:oracle:thin:@{server}:{port}/{db}',
      driver='oracle.jdbc.driver.OracleDriver',
      dbtable=f'{stg_schema}.WEB_SERVER_LOGS',
      user=user,
      password=passwd).mode('append').save()

print("Processing done")