import oracledb

def create_connection(user, passwd, server, port, db):
    conn = None
    try:
        conn = oracledb.connect(user=user, password=passwd,
                                dsn=f'{server}:{port}/{db}',
                               encoding="UTF-8")
        return conn
    except oracledb.Error as e:
        print(e)