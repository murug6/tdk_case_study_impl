import csv
import re
import db_ops
from datetime import datetime as DT
import json

print("loading configuraitons")

config = {}
with open('job_config.json', 'r') as f:
    config = json.load(f)

user = config['user']
passwd = config['passwd']
server = config['server']
port = config['port']
db = config['db']
stg_schema = config['stg_schema']
created_by_user = config['created_by_user']
data_path = config['data_path']
file_name = config['file_name']

print("start processing")
             
file_dt_str = file_name.split('.')[0]
lines = []
with open(f'{data_path}{file_name}') as file:
    lines = file.readlines()

lines_corrected = []
for l in lines:
    lines_corrected.append(re.sub("([\w:/]+\s[+-]\d{4})", lambda s: s.group(1).replace(" ", "Z"), l))  # to replace the space in request timestamp

csv_reader = csv.reader(lines_corrected, delimiter=' ', quotechar='"')


insert_query = f"INSERT INTO {stg_schema}.WEB_SERVER_LOGS (HOST_IP, CLIENT_ID, USER_ID, REQUEST_TIMESTAMP, REQUEST_METHOD, REQUESTED_OBJ, REQUEST_PROTOCOL, RESPONSE_STATUS, RESPONSE_OBJECT_SIZE, FILE_DATE, CREATED_BY) VALUES(:HOST_IP, :CLIENT_ID, :USER_ID, TO_TIMESTAMP_TZ(:in_str, 'yyyy-mm-dd hh24:mi:ss tzh:tzm'), :REQUEST_METHOD, :REQUESTED_OBJ, :REQUEST_PROTOCOL, :RESPONSE_STATUS, :RESPONSE_OBJECT_SIZE, TO_DATE(:FILE_DATE, 'yyyy-mm-dd'), :CREATED_BY)"

print("inserting data")

connection = db_ops.create_connection(user, passwd, server, port, db)
with connection.cursor() as cursor:
    for li in csv_reader:
        req_dt = DT.strptime(li[3], '[%d/%b/%Y:%H:%M:%SZ%z]')
        req_dt_str = DT.strftime(req_dt, '%Y-%m-%d %H:%M:%S %z')  # to convert datetime into formatted string accepted in Oracle
        cursor.execute(insert_query, (li[0], None if li[1]=='-' else li[1], li[2], req_dt_str,li[4].split(' ')[0], li[4].split(' ')[1], li[4].split(' ')[2], int(li[5]), int(li[6]), file_dt_str, created_by_user))

print("Commit and connection close")
connection.commit()
connection.close()