CREATE TABLE web_server_logs (
	system_guid RAW(32) DEFAULT SYS_GUID(),
	host_ip nvarchar2(20) NOT NULL,
	client_id nvarchar2(10) NULL,
	user_id INTEGER NOT NULL,
	request_timestamp TIMESTAMP WITH TIME ZONE NOT NULL,
	request_method nvarchar2(10) NOT NULL,
	requested_obj nvarchar2(255) NOT NULL,
	request_protocol nvarchar2(20) NOT NULL,
	response_status INTEGER NOT NULL,
	response_object_size int NULL,
	file_date date NOT NULL,
	created_on timestamp DEFAULT current_timestamp,
	created_by nvarchar2(255) NOT NULL
)

CREATE TABLE tdk_summary."user_level_summary" (
	system_guid RAW(32) DEFAULT SYS_GUID(),
	report_date date NOT NULL,
	user_id INTEGER NOT NULL,
	no_of_requests INTEGER NOT NULL,
	no_of_successfull_req INTEGER NOT NULL,
	no_of_client_errors INTEGER NOT NULL,	
	created_on timestamp DEFAULT current_timestamp,
	created_by nvarchar2(255) NOT NULL
);

CREATE TABLE tdk_summary."global_summary" (
	system_guid RAW(32) DEFAULT SYS_GUID(),
	report_date date NOT NULL,
	no_of_distinct_users INTEGER NOT NULL,
	no_of_requests INTEGER NOT NULL,
	no_of_successfull_req INTEGER NOT NULL,
	no_of_server_errors INTEGER NOT NULL,	
	created_on timestamp DEFAULT current_timestamp,
	created_by nvarchar2(255) NOT NULL
);
